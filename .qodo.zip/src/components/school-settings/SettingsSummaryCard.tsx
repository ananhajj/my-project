
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RealSchoolSettings } from '@/hooks/useRealSchoolSettings';

interface SettingsSummaryCardProps {
  settings: RealSchoolSettings;
}

export const SettingsSummaryCard = ({ settings }: SettingsSummaryCardProps) => {
  return (
    <Card className="bg-white/95 backdrop-blur-sm border-white/30 shadow-lg" dir="rtl">
      <CardHeader className="bg-school-beige/10 rounded-t-lg text-right">
        <CardTitle className="text-school-navy text-right">ملخص الإعدادات الحالية</CardTitle>
      </CardHeader>
      <CardContent className="pt-6 text-right">
        <div className="space-y-3 text-school-navy text-right">
          <p className="text-right"><strong>اسم المدرسة:</strong> <span className="text-school-blue">{settings.school_name || 'غير محدد'}</span></p>
          <p className="text-right"><strong>نوع تسجيل الحضور:</strong> <span className="text-school-teal">{settings.attendance_type === 'daily' ? 'يومي' : 'بالحصص'}</span></p>
          {settings.attendance_type === 'hourly' && (
            <p className="text-right"><strong>عدد الحصص:</strong> <span className="text-school-green">{settings.periods_per_day}</span></p>
          )}
          <p className="text-right"><strong>حالة النظام:</strong> <span className="text-school-green">مفعل ومتصل بقاعدة البيانات</span></p>
        </div>
      </CardContent>
    </Card>
  );
};
