
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BasicSchoolInfoCard } from './BasicSchoolInfoCard';
import { StageManagementCard } from './StageManagementCard';
import { AttendanceTypeCard } from './AttendanceTypeCard';
import { AlertSettingsCard } from './AlertSettingsCard';
import { SettingsSummaryCard } from './SettingsSummaryCard';

interface SchoolSettingsTabsProps {
  settings: any;
  orderedStages: any[];
  tempSchoolName: string;
  setTempSchoolName: (name: string) => void;
  handleSaveSettings: () => void;
  updateSettings: (updates: any) => Promise<void>;
}

export const SchoolSettingsTabs = ({
  settings,
  orderedStages,
  tempSchoolName,
  setTempSchoolName,
  handleSaveSettings,
  updateSettings
}: SchoolSettingsTabsProps) => {
  return (
    <Tabs defaultValue="basic" className="w-full" dir="rtl">
      <TabsList className="grid w-full grid-cols-5 mb-8 bg-white/70 backdrop-blur-sm">
        <TabsTrigger value="basic" className="text-sm font-medium">المعلومات الأساسية</TabsTrigger>
        <TabsTrigger value="stages" className="text-sm font-medium">المراحل والصفوف</TabsTrigger>
        <TabsTrigger value="attendance" className="text-sm font-medium">نوع الحضور</TabsTrigger>
        <TabsTrigger value="alerts" className="text-sm font-medium">إعدادات التنبيهات</TabsTrigger>
        <TabsTrigger value="summary" className="text-sm font-medium">ملخص الإعدادات</TabsTrigger>
      </TabsList>

      <TabsContent value="basic" className="space-y-6">
        <BasicSchoolInfoCard
          tempSchoolName={tempSchoolName}
          setTempSchoolName={setTempSchoolName}
          handleSaveSettings={handleSaveSettings}
          settings={settings}
          updateSettings={updateSettings}
        />
      </TabsContent>

      <TabsContent value="stages" className="space-y-6">
        <StageManagementCard 
          orderedStages={orderedStages} 
          updateSettings={updateSettings}
          settings={settings}
        />
      </TabsContent>

      <TabsContent value="attendance" className="space-y-6">
        <AttendanceTypeCard 
          settings={settings}
          updateSettings={updateSettings}
        />
      </TabsContent>

      <TabsContent value="alerts" className="space-y-6">
        <AlertSettingsCard 
          settings={settings}
          updateSettings={updateSettings}
        />
      </TabsContent>

      <TabsContent value="summary" className="space-y-6">
        <SettingsSummaryCard settings={settings} />
      </TabsContent>
    </Tabs>
  );
};
