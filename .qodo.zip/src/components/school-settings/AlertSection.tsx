
import { AlertRule } from '@/types/alertSettings';
import { AlertRuleCard } from './AlertRuleCard';
import { AlertSectionHeader } from './AlertSectionHeader';
import { AlertEmptyState } from './AlertEmptyState';

interface AlertSectionProps {
  type: 'absence' | 'late';
  alerts: AlertRule[];
  onAddAlert: () => void;
  onUpdateAlert: (updatedRule: AlertRule) => void;
  onDeleteAlert: (ruleId: string) => void;
}

export const AlertSection = ({ 
  type, 
  alerts, 
  onAddAlert, 
  onUpdateAlert, 
  onDeleteAlert 
}: AlertSectionProps) => {
  return (
    <div className="space-y-4">
      <AlertSectionHeader type={type} onAddAlert={onAddAlert} />
      
      <div className="grid gap-3">
        {alerts.map((rule) => (
          <AlertRuleCard
            key={rule.id}
            rule={rule}
            type={type}
            onUpdate={onUpdateAlert}
            onDelete={onDeleteAlert}
          />
        ))}
        {alerts.length === 0 && <AlertEmptyState type={type} />}
      </div>
    </div>
  );
};
