import { Outlet } from "react-router-dom";
 import Header from "./Header";
import Footer from "./Footer";
import { AppSidebar } from "./AppSidebar";

const SchoolLayout = () => {
  return (
    <div className="flex min-h-screen">
      <AppSidebar />
      <div className="flex flex-col flex-1">
        <Header />
        <main className="flex-1 p-4 overflow-y-auto">
          <Outlet />
        </main>
        <Footer />
      </div>
    </div>
  );
};

export default SchoolLayout;
