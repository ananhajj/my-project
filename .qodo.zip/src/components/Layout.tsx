
import { ReactNode, useState, useEffect } from "react";
import Header from "./Header";
import Footer from "./Footer";
import { AppSidebar } from "./AppSidebar";
import { SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "./AdminLayout";
import { useSubscriptionStatus } from "@/hooks/useSubscriptionStatus";

interface LayoutProps {
  children: ReactNode;
}

const LayoutContent = ({ children }: LayoutProps) => {
  const { open } = useSidebar();
  const { user } = useAuth();
  const { subscriptionStatus } = useSubscriptionStatus();

  // التحقق من نوع المستخدم
  const [userRole, setUserRole] = useState<string | null>(null);

  useEffect(() => {
    const getUserRole = async () => {
      if (user) {
        const { data: profile } = await supabase.auth.getUser();
        if (profile.user) {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('role')
            .eq('id', profile.user.id)
            .single();
          
          setUserRole(profileData?.role || 'school');
        }
      }
    };

    getUserRole();
  }, [user]);

  // إذا كان المستخدم مدير، استخدم تخطيط المدير بدون شريط جانبي
  if (userRole === 'admin') {
    return <AdminLayout>{children}</AdminLayout>;
  }

  // للمدارس: إذا كان الاشتراك منتهي أو معطل، لا تعرض التخطيط العادي
  if (userRole === 'school' && subscriptionStatus && !subscriptionStatus.is_active) {
    return <>{children}</>;
  }

  // تخطيط المدرسة العادي مع الشريط الجانبي - يظهر فوراً بدون انتظار
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 relative overflow-hidden" dir="rtl">
      {/* Animated background decorative elements */}
      <div className="absolute inset-0 opacity-[0.08] pointer-events-none">
        <div className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-br from-school-green to-school-teal rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-1/3 right-20 w-64 h-64 bg-gradient-to-br from-school-blue to-school-navy rounded-full blur-2xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-32 left-1/4 w-80 h-80 bg-gradient-to-br from-school-teal to-school-green rounded-full blur-3xl animate-pulse delay-500"></div>
        <div className="absolute bottom-20 right-16 w-48 h-48 bg-gradient-to-br from-school-navy to-school-blue rounded-full blur-xl animate-pulse delay-[1500ms]"></div>
      </div>
      
      {/* Floating geometric shapes */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
        <div className="absolute top-1/4 left-1/3 w-32 h-32 bg-school-green rotate-45 rounded-lg animate-bounce"></div>
        <div className="absolute top-2/3 right-1/4 w-24 h-24 bg-school-blue rotate-12 rounded-full animate-bounce delay-300"></div>
        <div className="absolute bottom-1/4 left-1/2 w-20 h-20 bg-school-teal -rotate-12 rounded-lg animate-bounce delay-700"></div>
      </div>
      
      {/* Subtle dot pattern overlay */}
      <div className="absolute inset-0 opacity-[0.015] pointer-events-none" 
           style={{
             backgroundImage: `radial-gradient(circle at 2px 2px, hsl(var(--school-navy)) 1px, transparent 0)`,
             backgroundSize: '40px 40px'
           }}>
      </div>
      
      {/* Gradient mesh overlay */}
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none bg-gradient-to-br from-transparent via-school-green/10 to-transparent"></div>
      
      {/* Layout structure with sidebar on the right - renders immediately */}
      <div className="relative min-h-screen w-full z-10">
        {/* Main content area - gets pushed left when sidebar is open */}
        <div 
          className={`min-h-screen transition-all duration-300 ease-in-out ${
            open ? 'mr-64' : 'mr-0'
          }`}
        >
          <Header />
          <main className="flex-1 backdrop-blur-[0.5px] p-4">
            <div className="flex justify-start mb-4">
              <SidebarTrigger className="bg-white/10 text-school-navy hover:bg-white/20 border border-white/20" />
            </div>
            <div className="max-w-full">
              {children}
            </div>
          </main>
          <Footer />
        </div>
        
        {/* Sidebar positioned on the right */}
        <AppSidebar />
      </div>
    </div>
  );
};

const Layout = ({ children }: LayoutProps) => {
  return (
    <SidebarProvider defaultOpen={false}>
      <LayoutContent>{children}</LayoutContent>
    </SidebarProvider>
  );
};

export default Layout;
