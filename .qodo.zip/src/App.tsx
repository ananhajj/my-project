
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Layout from "./components/Layout";
import Index from "./pages/Index";
import Students from "./pages/Students";
import Attendance from "./pages/Attendance";
import LateAttendance from "./pages/LateAttendance";
import Reports from "./pages/Reports";
import AdminLogin from "./pages/AdminLogin";
import Auth from "./pages/Auth";
import Login from "./pages/Login";
import AdminDashboard from "./pages/AdminDashboard";
import ContentManagement from "./pages/ContentManagement";
import SchoolSettings from "./pages/SchoolSettings";
import Profile from "./pages/Profile";
import ProtectedRoute from "./components/ProtectedRoute";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Layout>
            <Routes>
              <Route path="/" element={<Auth />} />
              <Route path="/login" element={<Auth />} />
              <Route path="/admin-login" element={<Navigate to="/auth" replace />} />
              <Route path="/school-login" element={<Navigate to="/auth" replace />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/dashboard" element={
                <ProtectedRoute requiredRole="school">
                  <Index />
                </ProtectedRoute>
              } />
              <Route path="/students" element={
                <ProtectedRoute requiredRole="school">
                  <Students />
                </ProtectedRoute>
              } />
              <Route path="/attendance" element={
                <ProtectedRoute requiredRole="school">
                  <Attendance />
                </ProtectedRoute>
              } />
              <Route path="/late-attendance" element={
                <ProtectedRoute requiredRole="school">
                  <LateAttendance />
                </ProtectedRoute>
              } />
              <Route path="/reports" element={
                <ProtectedRoute requiredRole="school">
                  <Reports />
                </ProtectedRoute>
              } />
              <Route path="/school-settings" element={
                <ProtectedRoute requiredRole="school">
                  <SchoolSettings />
                </ProtectedRoute>
              } />
              <Route path="/profile" element={
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              } />
              <Route path="/admin" element={
                <ProtectedRoute requiredRole="admin">
                  <AdminDashboard />
                </ProtectedRoute>
              } />
              <Route path="/content-management" element={
                <ProtectedRoute requiredRole="admin">
                  <ContentManagement />
                </ProtectedRoute>
              } />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Layout>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
