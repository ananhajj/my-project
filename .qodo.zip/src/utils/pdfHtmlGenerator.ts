
import { SchoolInfo } from '@/types/pdfTypes';

export const generatePDFHtml = (
  schoolInfo: SchoolInfo,
  studentsData: any[],
  selectedGrade: string,
  totalStudents: number
): string => {
  const currentDate = new Date().toLocaleDateString('ar-SA');
  const sortedStudents = [...studentsData].sort((a, b) => b.absenceDays - a.absenceDays);
  const filterInfo = selectedGrade ? `الصف: ${selectedGrade}` : 'جميع الطلاب';

  return `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <style>
        body { 
          font-family: 'Segoe UI', Tahoma, Arial, sans-serif; 
          direction: rtl; 
          margin: 0; 
          padding: 20px;
          background: white;
          color: #000;
          font-size: 12px;
        }
        .header { 
          display: flex; 
          justify-content: space-between; 
          align-items: flex-start; 
          margin-bottom: 25px; 
          border-bottom: 2px solid #333; 
          padding-bottom: 15px;
          min-height: 120px;
        }
        .org-info { 
          text-align: right; 
          flex: 1; 
          line-height: 1.8;
          font-size: 12px;
          padding-right: 10px;
        }
        .org-field {
          margin-bottom: 8px;
          font-size: 11px;
          color: #333;
        }
        .school-name {
          font-weight: bold;
          color: #2563eb;
          font-size: 16px;
          margin-top: 10px;
        }
        .logo-section { 
          text-align: center; 
          flex: 0 0 120px; 
          margin: 0 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        .logo-section img {
          width: 100px !important;
          height: 100px !important;
          object-fit: contain;
          display: block;
        }
        .target-info { 
          text-align: left; 
          flex: 1;
          font-size: 11px;
          line-height: 1.8;
          padding-left: 10px;
        }
        .target-field {
          margin-bottom: 8px;
        }
        .title { 
          text-align: center; 
          margin: 20px 0; 
          font-size: 18px !important; 
          font-weight: bold;
          color: #174459;
        }
        .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .table th { 
          background-color: #174459; 
          color: white; 
          padding: 12px; 
          border: 1px solid #000; 
          text-align: center; 
          font-weight: bold; 
        }
        .table td { 
          padding: 10px; 
          border: 1px solid #000; 
          text-align: center; 
        }
        .table tr:nth-child(even) { background-color: #f8fafc; }
        .status-normal { color: #10b981; font-weight: bold; }
        .status-warning { color: #eab308; font-weight: bold; }
        .status-medium { color: #d97706; font-weight: bold; }
        .status-high { color: #ea580c; font-weight: bold; }
        .status-severe { color: #dc2626; font-weight: bold; }
        .footer { margin-top: 40px; text-align: center; color: #666; font-size: 10px; }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="org-info">
          <div class="org-field">${schoolInfo.country}</div>
          <div class="org-field">${schoolInfo.ministry}</div>
          <div class="org-field">${schoolInfo.education_department}</div>
          <div class="org-field">${schoolInfo.educational_supervision}</div>
          <div class="school-name">${schoolInfo.school_name}</div>
        </div>
        
        <div class="logo-section">
          <img src="/lovable-uploads/81f958b0-0dce-425e-84d4-dd1c628754ff.png" alt="شعار وزارة التعليم" width="100" height="100">
        </div>
        
        <div class="target-info">
          <div class="target-field"><strong>الفئة المستهدفة:</strong></div>
          <div class="target-field">${filterInfo}</div>
          <div class="target-field" style="margin-top: 12px;"><strong>عدد الطلاب:</strong></div>
          <div class="target-field">${totalStudents}</div>
          <div class="target-field" style="margin-top: 12px;"><strong>تاريخ التقرير:</strong></div>
          <div class="target-field">${currentDate}</div>
        </div>
      </div>
      
      <div class="title">تقرير الغياب المفصل</div>
      
      <table class="table">
        <thead>
          <tr>
            <th>م</th>
            <th>اسم الطالب</th>
            <th>الصف/الشعبة</th>
            <th>أيام الغياب</th>
            <th>نسبة الحضور</th>
            <th>الحالة</th>
          </tr>
        </thead>
        <tbody>
          ${sortedStudents.map((student, index) => {
            let status = 'طبيعي';
            let statusClass = 'status-normal';
            
            if (student.absenceDays >= 5) {
              status = 'تحذير شديد';
              statusClass = 'status-severe';
            } else if (student.absenceDays >= 4) {
              status = 'تحذير عالي';
              statusClass = 'status-high';
            } else if (student.absenceDays >= 3) {
              status = 'تحذير متوسط';
              statusClass = 'status-medium';
            } else if (student.absenceDays >= 2) {
              status = 'تنبيه';
              statusClass = 'status-warning';
            }
            
            return `
              <tr>
                <td>${index + 1}</td>
                <td style="text-align: right;">${student.name}</td>
                <td>${student.grade} / ${student.section}</td>
                <td>${student.absenceDays}</td>
                <td>${student.attendancePercentage}%</td>
                <td class="${statusClass}">${status}</td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
      
      <div class="footer">
        <p>تم إنشاء هذا التقرير بواسطة نظام إدارة الحضور المدرسي - منصة حاضرون التعليمية</p>
      </div>
    </body>
    </html>
  `;
};
