
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { StudentWithAttendance } from '@/hooks/useAttendance';

export const generateStudentsListPDF = async (
  studentsData: StudentWithAttendance[],
  schoolName: string,
  filterInfo: string,
  selectedGrade?: string,
  selectedSection?: string,
  selectedStage?: string
) => {
  // Create a temporary HTML element with proper Arabic rendering
  const tempDiv = document.createElement('div');
  tempDiv.style.position = 'absolute';
  tempDiv.style.left = '-9999px';
  tempDiv.style.top = '-9999px';
  tempDiv.style.width = '794px'; // A4 width in pixels at 96 DPI
  tempDiv.style.padding = '40px';
  tempDiv.style.fontFamily = 'Tajawal, Arial, sans-serif';
  tempDiv.style.direction = 'rtl';
  tempDiv.style.backgroundColor = 'white';
  
  // Generate the HTML content
  const currentDate = new Date().toLocaleDateString('ar-SA');
  
  tempDiv.innerHTML = `
    <div style="text-align: center; margin-bottom: 30px; border-bottom: 3px solid #06a869; padding-bottom: 20px;">
      <div style="display: flex; align-items: center; justify-content: center; gap: 20px; margin-bottom: 15px;">
        <img src="/lovable-uploads/81f958b0-0dce-425e-84d4-dd1c628754ff.png" alt="شعار وزارة التعليم" style="width: 80px; height: 80px;">
        <div>
          <h1 style="color: #174459; font-size: 28px; margin: 0; font-weight: bold;">تقرير الغياب المفصل</h1>
          <h2 style="color: #06a869; font-size: 22px; margin: 10px 0;">${schoolName}</h2>
        </div>
      </div>
      <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin: 20px 0; padding: 15px; background-color: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0;">
        <div style="text-align: center;">
          <strong style="color: #174459; font-size: 16px;">الفئة المستهدفة:</strong><br>${filterInfo}
        </div>
        <div style="text-align: center;">
          <strong style="color: #174459; font-size: 16px;">تاريخ التقرير:</strong><br>${currentDate}
        </div>
        <div style="text-align: center;">
          <strong style="color: #174459; font-size: 16px;">عدد الطلاب:</strong><br>${studentsData.length}
        </div>
      </div>
    </div>
    
    <table style="width: 100%; border-collapse: collapse; font-size: 14px; margin-top: 20px;">
      <thead>
        <tr style="background-color: #174459; color: white;">
          <th style="padding: 12px; border: 1px solid #ddd; text-align: center; font-weight: bold;">م</th>
          <th style="padding: 12px; border: 1px solid #ddd; text-align: center; font-weight: bold;">اسم الطالب</th>
          <th style="padding: 12px; border: 1px solid #ddd; text-align: center; font-weight: bold;">الصف/الشعبة</th>
          <th style="padding: 12px; border: 1px solid #ddd; text-align: center; font-weight: bold;">أيام الغياب</th>
          <th style="padding: 12px; border: 1px solid #ddd; text-align: center; font-weight: bold;">نسبة الحضور</th>
          <th style="padding: 12px; border: 1px solid #ddd; text-align: center; font-weight: bold;">الحالة</th>
        </tr>
      </thead>
      <tbody>
        ${studentsData.map((student, index) => {
          let status = 'طبيعي';
          let statusColor = '#10b981';
          
          if (student.absenceDays >= 5) {
            status = 'تحذير شديد';
            statusColor = '#dc2626';
          } else if (student.absenceDays >= 4) {
            status = 'تحذير عالي';
            statusColor = '#ea580c';
          } else if (student.absenceDays >= 3) {
            status = 'تحذير متوسط';
            statusColor = '#d97706';
          } else if (student.absenceDays >= 2) {
            status = 'تنبيه';
            statusColor = '#eab308';
          }
          
          const rowBg = student.absenceDays >= 2 ? '#fef2f2' : (index % 2 === 0 ? '#f8fafc' : 'white');
          
          return `
            <tr style="background-color: ${rowBg};">
              <td style="padding: 10px; border: 1px solid #ddd; text-align: center;">${index + 1}</td>
              <td style="padding: 10px; border: 1px solid #ddd; text-align: right; font-weight: 500;">${student.name}</td>
              <td style="padding: 10px; border: 1px solid #ddd; text-align: center;">${student.grade} / ${student.section}</td>
              <td style="padding: 10px; border: 1px solid #ddd; text-align: center;">${student.absenceDays}</td>
              <td style="padding: 10px; border: 1px solid #ddd; text-align: center;">${student.attendancePercentage}%</td>
              <td style="padding: 10px; border: 1px solid #ddd; text-align: center; color: ${statusColor}; font-weight: bold;">${status}</td>
            </tr>
          `;
        }).join('')}
      </tbody>
    </table>
    
    <div style="margin-top: 40px; text-align: center; color: #666; font-size: 12px; border-top: 1px solid #e2e8f0; padding-top: 20px;">
      <p>تم إنشاء هذا التقرير بواسطة نظام إدارة الحضور المدرسي - منصة حاضرون التعليمية</p>
    </div>
  `;
  
  // Add to document
  document.body.appendChild(tempDiv);
  
  try {
    // Convert HTML to canvas
    const canvas = await html2canvas(tempDiv, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff'
    });
    
    // Create PDF
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgWidth = 210; // A4 width in mm
    const pageHeight = 297; // A4 height in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;
    let position = 0;
    
    // Add first page
    pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
    
    // Add additional pages if needed
    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    
    // Generate filename based on filters
    let fileName = 'تقرير_الغياب_المفصل';
    if (selectedGrade) fileName += `_${selectedGrade}`;
    if (selectedSection) fileName += `_${selectedSection}`;
    fileName += `_${new Date().toISOString().split('T')[0]}.pdf`;
    
    // Save the PDF
    pdf.save(fileName);
    
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw new Error('فشل في إنشاء ملف PDF');
  } finally {
    // Clean up
    document.body.removeChild(tempDiv);
  }
};
