// src/pages/LandingPage.tsx
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const LandingPage = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-8 bg-gradient-to-br from-slate-100 to-blue-50 p-6">
      <h1 className="text-3xl font-bold text-blue-800 text-center">مرحبًا بك في منصة حاضرون</h1>
      <p className="text-gray-600 text-center max-w-md">
        منصة ذكية لرصد الحضور والتأخر للطلاب في المدارس. اختر نوع الدخول أدناه.
      </p>
      <div className="flex gap-4">
        <Link to="/auth">
          <Button className="bg-school-green hover:bg-school-green/90 text-white px-6 py-3 rounded-xl">دخول المدرسة</Button>
        </Link>
        <Link to="/admin-login">
          <Button variant="outline" className="px-6 py-3 rounded-xl border-gray-300">دخول المدير</Button>
        </Link>
      </div>
    </div>
  );
};

export default LandingPage;
